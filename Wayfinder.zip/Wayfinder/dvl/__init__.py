__version__ = "1.00.00.24"
__author__ = "Teledyne RD Instruments"
__licence__ = "Copyright (C) Teledyne Marine 2020"